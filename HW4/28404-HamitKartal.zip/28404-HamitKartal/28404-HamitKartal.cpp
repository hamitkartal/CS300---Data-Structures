#include <iostream>
#include <string>
#include <fstream>
#include <vector>
#include <unordered_map>
#include <unordered_set>
#include <queue>
#define SIZE 28
using namespace std;

struct vertex
{
	string word;
	unsigned long distance;
	string path;
	vertex() {}
	vertex(string word, unsigned long distance, bool known, string path) : word(word), distance(distance), path(path) {}
};

string startWord, targetWord;
unordered_map<string, vertex> umap;
queue<vertex> Queue;
vertex* final_pt;
unordered_set<string> visited;
char alphabet[SIZE] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z', '\'', '-' };

bool substitution(const string& original_word, const vertex& front)
{
	for (int i = 0; i < original_word.length(); i++)
	{
		for (int j = 0; j < SIZE; j++)
		{
			if (original_word[i] == alphabet[j]) continue;
			string candidate = original_word;
			candidate[i] = alphabet[j];

			if (umap.find(candidate) != umap.end() && visited.find(candidate) == visited.end())
			{
				umap[candidate].distance = front.distance + 1;
				umap[candidate].path = front.path + umap[candidate].word + " (change " + original_word[i] + " at position " + to_string(i + 1) + " to " + alphabet[j] + ")" + "\n";
				Queue.push(umap[candidate]);
				visited.insert(candidate);
			}

			if (candidate == targetWord)
			{
				final_pt = &umap[candidate];
				return true;
			}
		}
	}
	return false;
}

bool deletion(const string& original_word, const vertex& front)
{
	for (int i = 0; i < original_word.length(); i++)
	{
		string candidate = original_word.substr(0, i) + original_word.substr(i + 1, original_word.length() - i - 1);
		if (umap.find(candidate) != umap.end() && visited.find(candidate) == visited.end())
		{
			umap[candidate].distance = front.distance + 1;
			umap[candidate].path = front.path + umap[candidate].word + " (delete " + original_word[i] + " at position " + to_string(i) + ")" + "\n";
			Queue.push(umap[candidate]);
			visited.insert(candidate);
		}

		if (candidate == targetWord)
		{
			final_pt = &umap[candidate];
			return true;
		}
	}
	return false;
}

bool insertion(const string& original_word, const vertex& front)
{
	for (int i = 0; i <= original_word.length(); i++)
	{
		for (int j = 0; j < SIZE; j++)
		{
			string candidate = original_word.substr(0, i) + alphabet[j] + original_word.substr(i, original_word.length() - i);
			if (umap.find(candidate) != umap.end() && visited.find(candidate) == visited.end())
			{
				umap[candidate].distance = front.distance + 1;
				umap[candidate].path = front.path + umap[candidate].word + " (insert " + alphabet[j] + " after position " + to_string(i) + ")" + "\n";
				Queue.push(umap[candidate]);
				visited.insert(candidate);
			}

			if (candidate == targetWord)
			{
				final_pt = &umap[candidate];
				return true;
			}
		}
	}
	return false;
}

void solve(vertex start)
{
	visited.clear();
	final_pt = nullptr;
	start.path = start.word + "\n";
	Queue.push(start);
	while (!Queue.empty())
	{
		vertex front = Queue.front();
		Queue.pop();

		string original_word = front.word;

		if (substitution(original_word, front))
			break;
		if (deletion(original_word, front))
			break;
		if (insertion(original_word, front))
			break;
	}

	while (!Queue.empty())
		Queue.pop();
	
	if (final_pt == NULL)
	{
		cout << "There is no solution!" << endl;
		return;
	}

	cout << final_pt->path << endl;
}

int main()
{

	cout << "Enter start and target word:";
	cin >> startWord >> targetWord;

	if (startWord[0] == '*') return 0;

	ifstream wordList;
	string fileName = "words.txt";
	wordList.open(fileName.c_str());

	string word;
	vector<string> word_vec;

	while (getline(wordList, word))
	{
		vertex* pt = new vertex(word, 0, false, "");
		umap[word] = *pt;
	}
		
	while (startWord[0] != '*')
	{
		if (umap.find(startWord) == umap.end() || umap.find(targetWord) == umap.end())
		{
			cout << "One of the words is not in the dictionary!" << endl;
			cout << "Enter start and target word:";
			cin >> startWord >> targetWord;
			continue;
		}

		solve(umap[startWord]);
		cout << "Enter start and target word:";
		cin >> startWord >> targetWord;
	}

	wordList.close();
	return 0;
}