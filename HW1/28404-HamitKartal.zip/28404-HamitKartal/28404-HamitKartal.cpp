#include <iostream>
#include <string>
#include <queue>
#include <vector>
#include <fstream>
using namespace std;

struct process
{
	queue<string> stages;
	int process_id;
};


int baba(const vector<queue<process>> & v)
{
	for (int i=v.size()-1; i >= 0; i--)
	{
		if (!v[i].empty())
			return i;
	}
	return -1;
}


void process_slider(vector<queue<process>> & v, ofstream & file)
{
	for (int i = v.size()-2; i >= 0; i--)
	{
		while (!v[i].empty())
		{
			file << "B, PC" << v[i].front().process_id << ", Q" << v.size() << endl;
			v[v.size()-1].push(v[i].front());
			v[i].pop();
		}
	}
}


int main()
{
	string process_file_name;
	cout << "Please enter the process folder name: ";
	cin >> process_file_name;

	cout << "When all processes are completed, you can find execution sequence in " << "\"" << process_file_name << "/output.txt\"." << endl;
	
	ifstream config;
	config.open((process_file_name + "/" + "configuration.txt").c_str());

	int number_of_queues;
	int number_of_processes;
	int TIME_SLICE;

	string temp;

	cin.clear();
	cin.ignore();

	getline(config, temp);
	number_of_queues = stoi(temp);
	getline(config, temp);	
	number_of_processes = stoi(temp);
	getline(config, temp);
	TIME_SLICE = stoi(temp);
	config.close();

	vector<queue<process>> queue_vector (number_of_queues);

	for (int i=1; i <= number_of_processes; i++)
	{
		process p;
		p.process_id = i;
		string id = to_string(i);

		ifstream proces;
		proces.open((process_file_name + "/p" + id + ".txt").c_str());

		while (getline(proces, temp))
			p.stages.push(temp);
		queue_vector[number_of_queues-1].push(p);

		proces.close();
	}

	int TIME_SLICE_COUNTER = 0;
	ofstream output;
	output.open((process_file_name + "/output.txt").c_str());

	while (true)
	{
		int index = baba(queue_vector);

		if (index != -1)
		{

			string command = queue_vector[index].front().stages.front();
			int pid = queue_vector[index].front().process_id;
			queue_vector[index].front().stages.pop();

			string next_command_check = queue_vector[index].front().stages.front();

			if (next_command_check == "-")
			{
				output << "E, PC" << pid << ", QX" << endl;
				queue_vector[index].front().stages.pop();
				queue_vector[index].pop();
			}

			else
			{
				if (command == "1")
				{
					if (index == 0)
					{
						output << command << ", PC" << pid << ", Q" << index+1 << endl;
						queue_vector[index].push(queue_vector[index].front());
						queue_vector[index].pop();
					}
					else
					{
						output << command << ", PC" << pid << ", Q" << index << endl;
						queue_vector[index-1].push(queue_vector[index].front());
						queue_vector[index].pop();
					}

				}

				else
				{
					output << command << ", PC" << pid << ", Q" << index+1 << endl;
					queue_vector[index].push(queue_vector[index].front());
					queue_vector[index].pop();
				}
			}

		}

		else
			break;

		TIME_SLICE_COUNTER++;

		if (TIME_SLICE_COUNTER == TIME_SLICE)
		{
			process_slider(queue_vector, output);
			TIME_SLICE_COUNTER = 0;
		}
	}


	output.close();

	return 0;
}
