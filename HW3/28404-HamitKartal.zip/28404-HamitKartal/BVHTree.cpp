#include "BVHTree.h"

BVHTree::BVHTree() { root = nullptr; }

BVHTree::~BVHTree() { }

void BVHTree::printNode(std::ostream &out, BVHTreeNode *node, int level) {
	if (root == nullptr) return;
	for (int i = 0; i < level; i++) {
		out << "  ";
	}
	if (!node->isLeaf) {
		out << "+ branch || ";
		node->aabb.printAABB(out);
		out << std::endl;
		printNode(out, node->rightChild, level + 1);
		printNode(out, node->leftChild, level + 1);
	}
	else {
		out << "- ";
		if (node->parent) {
			if (node->parent->rightChild == node)
				out << "R ";
			else
				out << "L ";
		}
		out << "- leaf: " << node->name << " || ";
		node->aabb.printAABB(out);
		out << std::endl;
	}
}


std::ostream &operator<<(std::ostream &out, BVHTree &tree) {
	tree.printNode(out, tree.root, 0);
	return out;
}

void BVHTree::addBVHMember(AABB objectArea, std::string name)
{
	if (root == nullptr)
	{
		root = new BVHTreeNode(objectArea, name, true);
		map[name] = root;
	}

	else if (root->isLeaf)
	{
		BVHTreeNode* newNode = new BVHTreeNode(objectArea, name, true);
		map[name] = newNode;
		BVHTreeNode* newRoot = new BVHTreeNode(root->aabb+newNode->aabb, "branch", false);
		newRoot->leftChild = newNode;
		newNode->parent = newRoot;
		newRoot->rightChild = root;
		root->parent = newRoot;
		root = newRoot;
	}

	else
	{
		BVHTreeNode* newNode = new BVHTreeNode(objectArea, name, true);
		map[name] = newNode;
		BVHTreeNode* existing_leaf = root;

		while (!existing_leaf->isLeaf)
		{
			int increaseInRightTreeSize = AABB::unionArea(newNode->aabb, existing_leaf->rightChild->aabb) - existing_leaf->rightChild->aabb.getArea();
			int increaseInLeftTreeSize = AABB::unionArea(newNode->aabb, existing_leaf->leftChild->aabb) - existing_leaf->leftChild->aabb.getArea();

			if (increaseInRightTreeSize < increaseInLeftTreeSize)
				existing_leaf = existing_leaf->rightChild;
			else
				existing_leaf = existing_leaf->leftChild;
		}

		BVHTreeNode* takeplace = new BVHTreeNode(newNode->aabb+existing_leaf->aabb, "branch", false);
		takeplace->leftChild = newNode;
		newNode->parent = takeplace;
		takeplace->rightChild = existing_leaf;
		
		if (existing_leaf->parent->leftChild == existing_leaf)
			existing_leaf->parent->leftChild = takeplace;
		else
			existing_leaf->parent->rightChild = takeplace;
		takeplace->parent = existing_leaf->parent;
		existing_leaf->parent = takeplace;
		
		BVHTreeNode* iterator = newNode->parent;
		while (iterator != NULL)
		{
			iterator->aabb = iterator->leftChild->aabb + iterator->rightChild->aabb;
			iterator = iterator->parent;
		}
	}
}


void BVHTree::moveBVHMember(std::string name, AABB newLocation)
{
	if (map.find(name) != map.end())
	{
		if (map[name] != root && newLocation + map[name]->parent->aabb != map[name]->parent->aabb)
		{
			removeBVHMember(name);
			addBVHMember(newLocation, name);
		}
		else
			map[name]->aabb = newLocation;
	}
}

void BVHTree::removeBVHMember(std::string name)
{
	if (map.find(name) != map.end())
	{
		BVHTreeNode* nodeToBeDeleted = map[name];

		if (nodeToBeDeleted == root)
		{
			delete nodeToBeDeleted;
			map.erase(name);
		}

		else if (nodeToBeDeleted->parent == root)
		{
			if (nodeToBeDeleted->parent->leftChild == nodeToBeDeleted)
			{
				nodeToBeDeleted->parent->rightChild->parent = NULL;
				delete nodeToBeDeleted;
				map.erase(name);
			}

			else
			{
				nodeToBeDeleted->parent->leftChild->parent = NULL;
				delete nodeToBeDeleted;
				map.erase(name);
			}
		}

		else
		{
			BVHTreeNode* parentNode = nodeToBeDeleted->parent;
			BVHTreeNode* grandParentNode = parentNode->parent;
			BVHTreeNode* sibling;
			if (nodeToBeDeleted->parent->leftChild == nodeToBeDeleted)
				sibling = nodeToBeDeleted->parent->rightChild;
			else
				sibling = nodeToBeDeleted->parent->leftChild;
			delete nodeToBeDeleted;
			sibling->parent = grandParentNode;
			if (parentNode->parent->leftChild == parentNode)
				grandParentNode->leftChild = sibling;
			else
				grandParentNode->rightChild = sibling;
			delete parentNode;

			BVHTreeNode* iterator = sibling->parent;
			while (iterator != NULL)
			{
				iterator->aabb = iterator->leftChild->aabb + iterator->rightChild->aabb;
				iterator = iterator->parent;
			}
		}
	}
}

void recursive (BVHTreeNode* node, std::vector<std::string>& v, const AABB& object)
{
	if (node->aabb.collide(object))
	{
		if (!node->isLeaf)
		{
			recursive(node->leftChild, v, object);
			recursive(node->rightChild, v, object);
		}

		else
			v.push_back(node->name);
	}
	return;
}

std::vector<std::string> BVHTree::getCollidingObjects(AABB object)
{
	std::vector<std::string> ret;
	recursive(root, ret, object);
	return ret;
}